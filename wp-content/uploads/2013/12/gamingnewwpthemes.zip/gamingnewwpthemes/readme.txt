Gaming theme by NewWpThemes, http://newwpthemes.com
Online Demo: http://newwpthemes.com/demo/Gaming/
Theme URI: http://newwpthemes.com/gaming-free-wordpress-theme/